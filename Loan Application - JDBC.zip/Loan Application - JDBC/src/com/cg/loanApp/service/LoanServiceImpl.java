package com.cg.loanApp.service;

import java.util.List;

import com.cg.loanApp.dao.LoanDao;
import com.cg.loanApp.dao.LoanDaoImpl;
import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.dto.Transaction;
import com.cg.loanApp.exception.LoanException;

public class LoanServiceImpl implements LoanService {

	private LoanDao dao;
	private static double emi;

	public LoanServiceImpl() {
		dao = new LoanDaoImpl();
	}

	/**
	 * Function to apply for Loan
	 * 
	 * @param accountNo - Account number of account for which loan is applied
	 * @param loan      - loan object that will get associated with initialized when
	 *                  loan is applied
	 */
	@Override
	public boolean applyLoan(int accountNo, Loan loan) {

		double rate = LoanService.RATE_OF_INTEREST / 100;
		int time = loan.getLoanTenure();
		double amount = (loan.getPrincipleAmt()) * (Math.pow((1 + rate / 12), time * 12));
		loan.setLoanAmount(amount);
		loan.setLoanRate(LoanService.RATE_OF_INTEREST);
		this.emi = calculateEmi(loan.getPrincipleAmt(), RATE_OF_INTEREST, loan.getLoanTenure());

		loan.setEmiLoan(emi);
		return dao.saveLoan(accountNo, loan) ? true : false;
	}

	/**
	 * Function to show balance
	 * 
	 * @param accountNo - Balance for respective account number will be shown
	 * @throws LoanException 
	 */
	@Override
	public void showBalance(int accountNo) throws LoanException {
		double balance = dao.getLoanDetails(accountNo).getLoanAmount();
		System.out.println("Your Outstanding Balance :");
		System.out.printf("Rs: %.2f", balance);
		System.out.println();
	}

	/**
	 * Function to pay EMI
	 * 
	 * @param accountNo - EMI for respective account number will be payed
	 * @throws LoanException 
	 */
	@Override
	public void payEmi(int accountNo) throws LoanException {
		Loan tempLoanValue = dao.getLoanDetails(accountNo);
		double amount = tempLoanValue.getLoanAmount();
		if (amount > 0) {
			System.out.println(tempLoanValue.getEmiLoan());
			amount -= tempLoanValue.getEmiLoan();
			tempLoanValue.setLoanAmount(amount);
			System.out.println("New Loan amount : service" + tempLoanValue.getLoanAmount());
//		List<Transaction> loantxns = tempLoanValue.getTxnList();
			Transaction txn = new Transaction(accountNo, " Emi ", emi, tempLoanValue.getLoanAmount());
//		dao.transactions(txn);
//		loantxns.add(txn);
			// tempLoanValue.setTxnList(loantxns);
			dao.updateAmount(accountNo, tempLoanValue);
			System.out.println("After updateamount -service");
			dao.saveTransaction(accountNo, txn);

		} else {
			System.out.println("Emi cannot be payed");
		}

	}

	/**
	 * Function to foreclose a loan
	 * 
	 * @param accountNo - loan associated with the account number will be foreclosed
	 * @throws LoanException 
	 */
	// Handle exceptions here
	@Override
	public void foreclose(int accountNo) throws LoanException {
		Loan tempLoanValue = dao.getLoanDetails(accountNo);
		tempLoanValue.setLoanAmount(0.0);
		Transaction txn = new Transaction(accountNo, "Loan Foreclosed ", 0.0, tempLoanValue.getLoanAmount());
		dao.updateAmount(accountNo, tempLoanValue);
		dao.saveTransaction(accountNo, txn);
	}

	/**
	 * Function which serves as a EMI calculator
	 * 
	 * @param principleAmt - principle amount for loan rate - rate of interest for
	 *                     loan tenure - time period for loan
	 */
	@Override
	public double calculateEmi(double principleAmt, double rate, int tenure) {
		double emi;
		rate = rate / 100;
		double amount = (principleAmt) * (Math.pow((1 + rate / 12), tenure * 12));
//		System.out.println(amount);
		emi = amount / (tenure * 12);
//		System.out.println(emi);
		return emi;
	}

	/**
	 * Function to print Transactions
	 * 
	 * @param accountNo - transactions related to respective account number will be
	 *                  printed
	 */
	@Override
	public void printTransaction(int accountNo) {
		List<Transaction> txns = dao.getTransaction(accountNo);
		for (Transaction transaction : txns) {
			System.out.println(transaction);
		}
	}

}
