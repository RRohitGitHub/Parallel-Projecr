package com.cg.loanApp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.dto.Transaction;
import com.cg.loanApp.exception.LoanException;
import com.cg.loanApp.util.JdbcFactory;

/**
 * LoanDaoImpl implementation
 * 
 * @author Rohit Bharat Parab
 *
 */
public class LoanDaoImpl implements LoanDao {

//	private HashMap<Integer, Loan> loanMap = new HashMap<Integer, Loan>();
	// private List<Transaction> txnList = new ArrayList<Transaction>();
	private List<Transaction> txnList;

	public LoanDaoImpl() {
		txnList = new ArrayList<Transaction>();
	}

	/**
	 * saveLoan implementation
	 */
	@Override
	public boolean saveLoan(int accountNo, Loan loan) {
		Connection conn = null;

		try {
			conn = JdbcFactory.getConnection();
			String sql = "insert into Loan_Master values(?,?,?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, accountNo);
			stmt.setDouble(2, loan.getPrincipleAmt());
			stmt.setInt(3, loan.getLoanTenure());
			stmt.setDouble(4, loan.getLoanRate());
			stmt.setDouble(5, loan.getLoanAmount());
			stmt.setDouble(6, loan.getEmiLoan());
			stmt.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

//	@Override
//	public Transaction displayTransaction(int accountNo) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	/**
	 * getLoanDetails() implementations
	 */
	@Override
	public Loan getLoanDetails(int accountNo) throws LoanException {
		String sql = "select * from Loan_Master where accountno=" + accountNo;
		Connection conn = null;

		try {
			conn = JdbcFactory.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			Loan loan = null;
			while (rs.next()) {
				loan = new Loan();
				loan.setAccountNo(rs.getInt(1));
				loan.setPrincipleAmt(rs.getDouble(2));
				loan.setLoanTenure(rs.getInt(3));
				loan.setLoanRate(rs.getDouble(4));
				loan.setLoanAmount(rs.getDouble(5));
				loan.setEmiLoan(rs.getDouble(6));
			}
			if (loan == null) {
				throw new LoanException("Loan with account no " + accountNo + " does not exist in database");
			}
			return loan;
		} catch (SQLException e) {
			e.printStackTrace();
//			return null;
//			throw new LoanException("Loan with account no "+accountNo+" does not exist in database");
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
//					return null;
				}
			}
		}
		return null;
		
	}

	/**
	 * updateAmount() implementation
	 */
	@Override
	public void updateAmount(int accountNo, Loan loan) {
		Connection conn = null;
		double amount = loan.getLoanAmount();

		try {
			conn = JdbcFactory.getConnection();
			String update = "Update Loan_Master set loanamount=? where accountno=" + accountNo;
			PreparedStatement stmt = conn.prepareStatement(update);
			stmt.setDouble(1, amount);
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * saveTransaction implementation
	 */
	@Override
	public void saveTransaction(int accountNo, Transaction txn) {
		Connection conn = null;

		try {
			conn = JdbcFactory.getConnection();
			String sql = "insert into Transaction_Master values(?,?,?,?)";
			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setInt(1, txn.getAccountNo());
			stmt.setString(2, txn.getParticulars());
			stmt.setDouble(3, txn.getEmiAmount());
			stmt.setDouble(4, txn.getOutBalance());
			stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * getTransaction implementations
	 */
	@Override
	public List<Transaction> getTransaction(int accountNo) {
		Connection conn = null;

		try {
			conn = JdbcFactory.getConnection();
			String sql = "select * from Transaction_Master where accountno=" + accountNo;
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				Transaction txn = new Transaction();
				txn.setAccountNo(rs.getInt(1));
				txn.setParticulars(rs.getString(2));
				txn.setEmiAmount(rs.getDouble(3));
				txn.setOutBalance(rs.getDouble(4));
				txnList.add(txn);
			}
			return txnList;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
