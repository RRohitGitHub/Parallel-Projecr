package com.cg.loanApp.dao;

import java.util.List;

import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.dto.Transaction;
import com.cg.loanApp.exception.LoanException;

/**
 * Interface for LoanDao
 * @author Rohit Bharat Parab
 *
 */
public interface LoanDao {
	/**
	 * saveLoan declaration
	 * @param accountNo
	 * @param loan
	 * @return
	 */
	boolean saveLoan(int accountNo,Loan loan);
	
	/**
	 * getLoanDetaisl declaration
	 * @param accountNo
	 * @return Loan
	 * @throws LoanException
	 */
	Loan getLoanDetails(int accountNo) throws LoanException;
	
	/**
	 * updateAmount() declaration
	 * @param accountNo
	 * @param loan
	 */
	void updateAmount(int accountNo,Loan loan);
	
	/**
	 * saveTransaction() declaration
	 * @param accountNo
	 * @param txn
	 */
	void saveTransaction(int accountNo,Transaction txn);
	
	/**
	 * getTransaction() declaration
	 * @param accountNo
	 * @return
	 */
	List<Transaction> getTransaction(int accountNo);
//	List<Transaction> getTxnList();
//	Transaction displayTransaction(int accountNo);
//	void transactions(Transaction txns);
}
