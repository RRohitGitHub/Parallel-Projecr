package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transaction_Master_Spring")
public class Transaction {

	@Column(length=30)
	private int accountNo;
	
	@Id
	private int txnId;
	
	@Column(length=30)
	private String particulars;
	
	@Column(length=10)
	private double emiAmount;
	
	@Column(length=10)
	private double outBalance;

	private static int autoInc;

	static {
		autoInc = 1;
	}

	public Transaction() {
	}

	public Transaction(int accountNo, String particulars, double emiAmount, double outBalance) {
		this.accountNo = accountNo;
		this.txnId = autoInc++;
		this.particulars = particulars;
		this.emiAmount = emiAmount;
		this.outBalance = outBalance;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public int getTxnId() {
		return txnId;
	}

	public void setTxnId(int txnId) {
		this.txnId = txnId;
	}

	public String getParticulars() {
		return particulars;
	}

	public void setParticulars(String particulars) {
		this.particulars = particulars;
	}

	public double getEmiAmount() {
		return emiAmount;
	}

	public void setEmiAmount(double emiAmount) {
		this.emiAmount = emiAmount;
	}

	public double getOutBalance() {
		return outBalance;
	}

	public void setOutBalance(double outBalance) {
		this.outBalance = outBalance;
	}

	@Override
	public String toString() {
		return "Account No :" + accountNo + " Particulars :" + particulars + " EMI :" + emiAmount
				+ " Outstanding Amount :" + outBalance;
	}

}
