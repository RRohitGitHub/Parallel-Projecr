package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Loan_Master_Spring")
public class Loan {

	@Id
	private int accountNo;

	@Column(length = 30)
	private double principleAmt;
//	private int loanId;

	@Column(length = 30)
	private int loanTenure;

	@Column(length = 30)
	private double loanRate;

	@Column(length = 30)
	private double loanAmount;

	@Column(length = 30)
	private double emiLoan;

//	private List<Transaction> txnList = new ArrayList<Transaction>();
//
//	public List<Transaction> getTxnList() {
//		return txnList;
//	}
//
//	public void setTxnList(List<Transaction> txnList) {
//		this.txnList = txnList;
//	}

	private static int autoInc;

	static {
		autoInc = 101;
	}

	public Loan() {
	}

	public Loan(double principleAmt, double loanAmount, int loanTenure, int accountNo) {
		this.principleAmt = principleAmt;
//		this.loanId = autoInc++;
		this.loanAmount = loanAmount;
		this.loanTenure = loanTenure;
		this.accountNo = accountNo;
	}

//	public int getLoanId() {
//		return loanId;
//	}
//
//	public void setLoanId(int loanId) {
//		this.loanId = loanId;
//	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public int getLoanTenure() {
		return loanTenure;
	}

	public void setLoanTenure(int loanTenure) {
		this.loanTenure = loanTenure;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public double getPrincipleAmt() {
		return principleAmt;
	}

	public void setPrincipleAmt(double principleAmt) {
		this.principleAmt = principleAmt;
	}

	public double getLoanRate() {
		return loanRate;
	}

	public void setLoanRate(double loanRate) {
		this.loanRate = loanRate;
	}

	public double getEmiLoan() {
		return emiLoan;
	}

	public void setEmiLoan(double emiLoan) {
		this.emiLoan = emiLoan;
	}

	@Override
	public String toString() {
		return "Loan [principleAmt=" + principleAmt + ", loanRate=" + loanRate + ", loanAmount=" + loanAmount
				+ ", loanTenure=" + loanTenure + ", accountNo=" + accountNo + ", emiLoan=" + emiLoan + "]";
	}

}
