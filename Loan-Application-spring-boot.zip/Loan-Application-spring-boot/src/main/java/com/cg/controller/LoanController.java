package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Loan;
import com.cg.entity.Transaction;
import com.cg.service.LoanService;

@CrossOrigin(origins="http://localhost:4200")
@RestController

public class LoanController {

	@Autowired
	private LoanService service;
	
//	@PostMapping(value="/applyLoan",consumes="application/json")
//	public String applyForLoan(@RequestBody Loan loan) {
	@PostMapping(value="/applyLoan")
	public Loan applyForLoan(@RequestBody Loan loan) {
	if(service.applyLoan(loan))
			return loan;
		else
			return null;
	}
	
//	@GetMapping(value="/showBal/{acno}",produces="application/json")
//	public String showBalanceForLoan(@PathVariable("acno")int accountno) {
	@GetMapping(value="/showBal/{acno}")
	public Loan showBalanceForLoan(@PathVariable("acno")int accountno) {
//		double balance = service.showBalance(accountno);
//		return "Your Outstanding Balance :"+balance;
		Loan loan = service.showBalance(accountno);
		return loan;
	}
	
//	@GetMapping(value="/payemi/{acno}",produces="application/json")
//	public String payEmiForLoan(@PathVariable("acno")int accountno) {
	@GetMapping(value="/payemi/{acno}")
	public boolean payEmiForLoan(@PathVariable("acno")int accountno) {
//		return service.payEmi(accountno);
		boolean status = service.payEmi(accountno);
		if(status==true) {
			return true;
		}else {
			return false;
		}
	}
	
//  @GetMapping(value="/forclose/{acno}",produces="application/json")
//	public String forecloseLoan(@PathVariable("acno")int accountno) {
	@GetMapping(value="/forclose/{acno}")
	public boolean forecloseLoan(@PathVariable("acno")int accountno) {
//		return service.foreclose(accountno);
		boolean status = service.foreclose(accountno);
		if(status==true) {
			return true;
		}else {
			return false;
		}
	}
	
//	@GetMapping(value="/calculateemi/{principle}/{rate}/{tenure}",produces="application/json")
//	public String calculateEmiForLoan(@PathVariable("principle")double principle,@PathVariable("rate")double rate,@PathVariable("tenure")int tenure) {
	@GetMapping(value="/calculateemi/{principle}/{rate}/{tenure}")
	public Loan calculateEmiForLoan(@PathVariable("principle")double principle,@PathVariable("rate")double rate,@PathVariable("tenure")int tenure) {
		double emiValue = service.calculateEmi(principle, rate, tenure);
//		return "Your EMI is:"+emiValue;
		Loan loan = new Loan();
		loan.setEmiLoan(emiValue);
		return loan;
	}
	
//	@GetMapping(value="/printTrans/{acno}",produces="application/json")
	@GetMapping(value="/printTrans/{acno}")
	public List<Transaction> printAllTransaction(@PathVariable("acno")int accountno){
		return service.printTransaction(accountno);
	}
}
