package com.cg.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;


@ControllerAdvice
public class LoanExceptionHandler {

	@ExceptionHandler({ Exception.class })
	protected ResponseEntity<String> handleConflict(Exception ex, WebRequest req) {
		String msg = ex.getMessage();
		if (msg.isEmpty()) {
			return new ResponseEntity<>("Invalid Input : Input Format Incorrect!!", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(msg, HttpStatus.NOT_FOUND);
	}
}
