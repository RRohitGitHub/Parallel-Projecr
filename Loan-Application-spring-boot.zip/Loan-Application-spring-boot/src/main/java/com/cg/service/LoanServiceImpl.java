package com.cg.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Loan;
import com.cg.entity.Transaction;
import com.cg.exception.LoanException;
import com.cg.repo.LoanRepo;
import com.cg.repo.TransactionRepo;

@Service
@Transactional
public class LoanServiceImpl implements LoanService {

	private static double emi;

	@Autowired
	private LoanRepo loanrepo;

	@Autowired
	private TransactionRepo transrepo;

	@Override
	public boolean applyLoan(Loan loan) {

		double rate = LoanService.RATE_OF_INTEREST / 100;
		int time = loan.getLoanTenure();
		double amount = (loan.getPrincipleAmt()) * (Math.pow((1 + rate / 12), time * 12));
		loan.setLoanAmount(amount);
		loan.setLoanRate(LoanService.RATE_OF_INTEREST);
		this.emi = calculateEmi(loan.getPrincipleAmt(), RATE_OF_INTEREST, loan.getLoanTenure());

		loan.setEmiLoan(emi);
//		return dao.saveLoan(accountNo, loan) ? true : false;
		if (loanrepo.save(loan) != null) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	//Bydefault return type was concatened string
	public Loan showBalance(int accountNo) {
		Optional<Loan> loanopt = loanrepo.findById(accountNo);
		if (!loanopt.isPresent()) {
			throw new LoanException(accountNo);
		} else {
			Loan loan = loanrepo.findById(accountNo).get();
//			double balance = loan.getLoanAmount();
//		System.out.println("Your Outstanding Balance :");
//		System.out.printf("Rs: %.2f", balance);
			return loan;
		}
	}

	@Override
	//Bydefault return type was string
	public boolean payEmi(int accountNo) {
		Optional<Loan> loanopt = loanrepo.findById(accountNo);
		if (!loanopt.isPresent()) {
			throw new LoanException(accountNo);
		} else {
//		Loan tempLoanValue = dao.getLoanDetails(accountNo);
			Loan tempLoanValue = loanrepo.findById(accountNo).get();
			double amount = tempLoanValue.getLoanAmount();
			if (amount > 0) {
				System.out.println(tempLoanValue.getEmiLoan());
				amount -= tempLoanValue.getEmiLoan();
				tempLoanValue.setLoanAmount(amount);
				System.out.println("New Loan amount : service" + tempLoanValue.getLoanAmount());
//		List<Transaction> loantxns = tempLoanValue.getTxnList();
				Transaction txn = new Transaction(accountNo, " Emi ", tempLoanValue.getEmiLoan(), tempLoanValue.getLoanAmount());
//		dao.transactions(txn);
//		loantxns.add(txn);
				// tempLoanValue.setTxnList(loantxns);
//			dao.updateAmount(accountNo, tempLoanValue);
				loanrepo.save(tempLoanValue);
//				System.out.println("After updateamount -service");
//			dao.saveTransaction(accountNo, txn);
				transrepo.save(txn);
				return true;
			} else {
//			System.out.println("Emi cannot be payed");
				return false;
			}
		}

	}

	@Override
	//Bydefault return type was string
	public boolean foreclose(int accountNo) {
		Optional<Loan> loanopt = loanrepo.findById(accountNo);
		if (!loanopt.isPresent()) {
			throw new LoanException(accountNo);
		} else {
//		Loan tempLoanValue = dao.getLoanDetails(accountNo);
			Loan tempLoanValue = loanrepo.findById(accountNo).get();
			tempLoanValue.setLoanAmount(0.0);
			Transaction txn = new Transaction(accountNo, "Loan Foreclosed ", 0.0, tempLoanValue.getLoanAmount());
//		dao.updateAmount(accountNo, tempLoanValue);
			loanrepo.save(tempLoanValue);
//		dao.saveTransaction(accountNo, txn);
			transrepo.save(txn);
			return true;
		}
	}

	@Override
	public double calculateEmi(double principleAmt, double rate, int tenure) {
		double emi;
		rate = rate / 100;
		double amount = (principleAmt) * (Math.pow((1 + rate / 12), tenure * 12));
//		System.out.println(amount);
		emi = amount / (tenure * 12);
//		System.out.println(emi);
		return emi;
	}

	@Override
	public List<Transaction> printTransaction(int accountNo) {
		List<Transaction> txns = transrepo.getAllTransaction(accountNo);
//		for (Transaction transaction : txns) {
//			System.out.println(transaction);
//		}
		return txns;
	}

}
