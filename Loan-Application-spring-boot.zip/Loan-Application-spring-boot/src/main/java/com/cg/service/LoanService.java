package com.cg.service;

import java.util.List;

import com.cg.entity.Loan;
import com.cg.entity.Transaction;

public interface LoanService {

final double RATE_OF_INTEREST = 10;
	
	boolean applyLoan(Loan loan);
	Loan showBalance(int accountNo);
	boolean payEmi(int accountNo);
	boolean foreclose(int accountNo);
	double calculateEmi(double principleAmt,double rate,int tenure);
	List<Transaction> printTransaction(int accountNo);
}
