package com.cg.exception;

public class LoanException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoanException(int acno) {
		super("Loan with account number " + acno + " not found in database");
	}
}
