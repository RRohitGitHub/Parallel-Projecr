package com.cg.loanApp.service;

import java.util.List;

import com.cg.loanApp.dao.LoanDao;
import com.cg.loanApp.dao.LoanDaoImpl;
import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.dto.Transaction;
import com.cg.loanApp.exception.LoanException;

public class LoanServiceImpl implements LoanService {

	private LoanDao dao;
	private static double emi;

	public LoanServiceImpl() {
		dao = new LoanDaoImpl();
	}

	/**
	 * Function to apply for Loan
	 * 
	 * @param accountNo - Account number of account for which loan is applied
	 * @param loan      - loan object that will get associated with initialized when
	 *                  loan is applied
	 */
	@Override
	public boolean applyLoan(int accountNo, Loan loan) {

		double rate = LoanService.RATE_OF_INTEREST / 100;
		int time = loan.getLoanTenure();
		double amount = (loan.getPrincipleAmt()) * (Math.pow((1 + rate / 12), time * 12));
		loan.setLoanAmount(amount);
		loan.setLoanRate(LoanService.RATE_OF_INTEREST);
		this.emi = calculateEmi(loan.getPrincipleAmt(), RATE_OF_INTEREST, loan.getLoanTenure());
		return dao.saveLoan(accountNo, loan) ? true : false;
	}

	/**
	 * Function to show balance
	 * 
	 * @param accountNo - Balance for respective account number will be shown
	 * @throws LoanException 
	 */
	@Override
	public void showBalance(int accountNo) throws LoanException {
		double balance = dao.getLoanDetails(accountNo).getLoanAmount();
		System.out.println("Your Outstanding Balance :");
		System.out.printf("Rs: %.2f", balance);
		System.out.println();
	}

	/**
	 * Function to pay EMI
	 * 
	 * @param accountNo - EMI for respective account number will be payed
	 * @throws LoanException 
	 */
	@Override
	public void payEmi(int accountNo) throws LoanException {
		Loan tempLoanValue = dao.getLoanDetails(accountNo);
		double amount = tempLoanValue.getLoanAmount();
		if(amount>0) {
		amount -= emi;
		tempLoanValue.setLoanAmount(amount);
		List<Transaction> loantxns = tempLoanValue.getTxnList();
		Transaction txn = new Transaction(accountNo, " Emi ", emi, tempLoanValue.getLoanAmount());
//		dao.transactions(txn);
		loantxns.add(txn);
		tempLoanValue.setTxnList(loantxns);
		dao.saveLoan(accountNo, tempLoanValue);
		}
		else {
			System.out.println("Emi cannot be payed");
		}
		
	}

	/**
	 * Function to foreclose a loan
	 * 
	 * @param accountNo - loan associated with the account number will be foreclosed
	 * @throws LoanException 
	 */
	// Handle exceptions here
	@Override
	public void foreclose(int accountNo) throws LoanException {
		Loan tempLoanValue = dao.getLoanDetails(accountNo);
		List<Transaction> loantxns = tempLoanValue.getTxnList();

		tempLoanValue.setLoanAmount(0.0);
		Transaction txn = new Transaction(accountNo, "Loan Foreclosed ", 0.0, tempLoanValue.getLoanAmount());
		loantxns.add(txn);
		tempLoanValue.setTxnList(loantxns);
		dao.saveLoan(accountNo, tempLoanValue);
	}

	/**
	 * Function which serves as a EMI calculator
	 * 
	 * @param principleAmt - principle amount for loan rate - rate of interest for
	 *                     loan tenure - time period for loan
	 */
	@Override
	public double calculateEmi(double principleAmt, double rate, int tenure) {
		double emi;
		rate = rate / 100;
		double amount = (principleAmt) * (Math.pow((1 + rate / 12), tenure * 12));
//		System.out.println(amount);
		emi = amount / (tenure * 12);
//		System.out.println(emi);
		return emi;
	}

	/**
	 * Function to print Transactions
	 * 
	 * @param accountNo - transactions related to respective account number will be
	 *                  printed
	 * @throws LoanException 
	 */
	@Override
	public void printTransaction(int accountNo) throws LoanException {
		Loan tempLoanValue = dao.getLoanDetails(accountNo);
		List<Transaction> txns = tempLoanValue.getTxnList();
		for (Transaction transaction : txns) {
			System.out.println(transaction);
		}
	}
	
	/**
	 * Methods to validate accountno,tenure,rateofInterest,principle amount
	 * 
	 */
	
	
	public boolean accountNoValidate(int accountNo) {
		if(accountNo>0) {
			return true;
		}else {
			return false;
		}
	}
	
	 public boolean tenureValidate(int tenure) {
		if(tenure>0) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean principleAmtValidate(double principleAmt) {
		if(principleAmt>0) {
			return true;
		}else {
			return false;
		}
	 }
	
	public boolean rateValidate(double rate) {
		if(rate>0) {
			return true;
		}else {
			return false;
		}
	 }

}
