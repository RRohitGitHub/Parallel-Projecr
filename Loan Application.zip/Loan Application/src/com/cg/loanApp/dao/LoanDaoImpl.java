package com.cg.loanApp.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.dto.Transaction;
import com.cg.loanApp.exception.LoanException;
import com.cg.loanApp.service.LoanService;

public class LoanDaoImpl implements LoanDao {

	
	private HashMap<Integer, Loan> loanMap = new HashMap<Integer, Loan>();
	//private List<Transaction> txnList = new ArrayList<Transaction>();

	/**
	 * Function to saveLoan to collections
	 * @param int accountNo
	 * @param Loan laon 
	 */
	@Override
	public boolean saveLoan(int accountNo, Loan loan) {
		loanMap.put(accountNo, loan);
		if (loanMap.size() > 0)
			return true;
		else
			return false;
	}

//	@Override
//	public Transaction displayTransaction(int accountNo) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	/**
	 * Function to get Loan details
	 * @param int accountNo
	 */
	@Override
	public Loan getLoanDetails(int accountNo) throws LoanException {
		Loan loan = loanMap.get(accountNo);
		if(loan==null) {
			throw new LoanException("Loan with "+accountNo+" not found");
		}
		return loan;
	
	}

//	public List<Transaction> getTxnList() {
//		return txnList;
//	}
//
//	public void setTxnList(List<Transaction> txnList) {
//		this.txnList = txnList;
//	}
//
//	@Override
//	public void transactions(Transaction txns) {
//		txnList.add(txns);
//	}
	
}
