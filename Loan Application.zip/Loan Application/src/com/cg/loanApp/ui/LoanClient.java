package com.cg.loanApp.ui;

import java.util.Scanner;

import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.exception.LoanException;
import com.cg.loanApp.service.LoanService;
import com.cg.loanApp.service.LoanServiceImpl;

public class LoanClient {
	private LoanService service = new LoanServiceImpl();
	private LoanServiceImpl serviceimpl = new LoanServiceImpl();
	Scanner sc = new Scanner(System.in);

	public void applyForLoan() {
		int accountNo;
		double principle;
		int tenure;
		do {
			System.out.println("Enter account no");
			accountNo = sc.nextInt();
		} while (!serviceimpl.accountNoValidate(accountNo));
		do {
			System.out.println("Enter amount");
			principle = sc.nextDouble();
		} while (!serviceimpl.principleAmtValidate(principle));
		do {
			System.out.println("Enter duration of time in years");
			tenure = sc.nextInt();
		} while (!serviceimpl.tenureValidate(tenure));

		Loan loan = new Loan(principle, 0.0, tenure, accountNo);
		if (service.applyLoan(accountNo, loan)) {
			System.out.println("Loan Applied Successfully");
		} else {
			System.out.println("Loan Cannot be applied");
		}
	}

	public void showBal() {
		int accountNo;
		do {
			System.out.println("Enter account no");
			accountNo = sc.nextInt();
		} while (!serviceimpl.accountNoValidate(accountNo));
		try {
			service.showBalance(accountNo);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}

	public void calcEmi() {
		double principle;
		int time;
		double rate;
		do {
			System.out.println("Enter principle amount");
			principle = sc.nextDouble();
		} while (!serviceimpl.principleAmtValidate(principle));

		do {
			System.out.println("Enter time period");
			time = sc.nextInt();
		} while (!serviceimpl.tenureValidate(time));

		do {
			System.out.println("Enter rate of interest");
			rate = sc.nextDouble();
		} while (!serviceimpl.rateValidate(rate));
		System.out.println(service.calculateEmi(principle, rate, time));
	}

	public void forecloseLoan() {
		int accountNo;
		do {
			System.out.println("Enter account no");
			accountNo = sc.nextInt();
		} while (!serviceimpl.accountNoValidate(accountNo));
		try {
			service.foreclose(accountNo);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}

	public void payEmi() {
		int accountNo;
		do {
			System.out.println("Enter account no");
			accountNo = sc.nextInt();
		} while (!serviceimpl.accountNoValidate(accountNo));
		try {
			service.payEmi(accountNo);
		} catch (LoanException e) {
//			e.printStackTrace();
			System.out.println(e.getMessage());
		}

	}

	public void printTransaction() {

		int accountNo;
		do {
			System.out.println("Enter account no");
			accountNo = sc.nextInt();
		} while (!serviceimpl.accountNoValidate(accountNo));
		System.out.println("Print transaction");
		try {
			service.printTransaction(accountNo);
		} catch (LoanException e) {
//			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		LoanClient c = new LoanClient();
		int ch = 0;
		do {
			System.out.println("1: Apply Loan");
			System.out.println("2: Show Balance");
			System.out.println("3: Pay EMI");
			System.out.println("4: Foreclose");
			System.out.println("5: Calculate EMI");
			System.out.println("6: Print Transactions");
			System.out.println("7: EXIT");
			System.out.println("Enter your choice");
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				c.applyForLoan();
				break;
			case 2:
				c.showBal();
				break;
			case 3:
				c.payEmi();
				break;
			case 4:
				c.forecloseLoan();
				break;
			case 5:
				c.calcEmi();
				break;
			case 6:
				c.printTransaction();
				break;

			case 7:
				System.out.println("Exited");
				break;
			default:
				System.out.println("Please Enter correct choice");
				break;
			}

		} while (ch != 7);
	}
}
