package com.cg.loanApp.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.cg.loanApp.dao.LoanDao;
import com.cg.loanApp.dao.LoanDaoImpl;
import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.exception.LoanException;

public class TestLoanDao {

	private LoanDao dao;

	@Before
	public void init() {
		dao = new LoanDaoImpl();
	}

	/**
	 * Testing saveLoan() 
	 */
	@Test
	public void testSaveLoan() {
		Loan loan = new Loan(10000, 0.0, 2, 1234);
		assertEquals(true, dao.saveLoan(1234, loan));
	}

	/**
	 * Testing get Loan Details
	 */
	@Test
	public void testGetLoanDetails() {
		Loan loan = new Loan(10000, 0.0, 2, 1234);
		dao.saveLoan(1234, loan);
		try {
			Loan temploan = dao.getLoanDetails(1234);
			assertEquals(loan, temploan);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * Testing LoanException
	 * @throws LoanException
	 */
	@Test(expected=LoanException.class)
	public void testgetLoanException() throws LoanException {
		dao.getLoanDetails(1234);
	}
}
