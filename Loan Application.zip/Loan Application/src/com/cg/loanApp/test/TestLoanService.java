package com.cg.loanApp.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cg.loanApp.dao.LoanDao;
import com.cg.loanApp.dao.LoanDaoImpl;
import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.dto.Transaction;
import com.cg.loanApp.exception.LoanException;
import com.cg.loanApp.service.LoanService;
import com.cg.loanApp.service.LoanServiceImpl;

public class TestLoanService {

	private LoanService service;
	private LoanDao dao;

	@Before
	public void init() {
		service = new LoanServiceImpl();
		dao = new LoanDaoImpl();
	}

	/**
	 * Testing calculateEmi() from service
	 */
	@Test
	public void testCalculateEmi() {
		double emi = service.calculateEmi(20000, 10, 2);
		assertEquals(1016.992467812966, emi, 0.0000000000001);
	}

	
	/**
	 * Testing foreclose() functionality from service
	 */
	@Test
	public void testForeclose() {
		try {
			Loan loan = new Loan(20000, 0.0, 2, 1234);
			service.applyLoan(1234, loan);
			service.foreclose(1234);
			assertEquals(0.0, loan.getLoanAmount(), 0.0001);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}
	

}
