package com.cg.loanApp.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.cg.loanApp.dao.LoanDao;
import com.cg.loanApp.dao.LoanDaoImpl;
import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.dto.Transaction;
import com.cg.loanApp.exception.LoanException;
import com.cg.loanApp.service.LoanService;
import com.cg.loanApp.service.LoanServiceImpl;

public class TestLoanDao {

	private LoanDao dao;
	private LoanService service;
	
	@Before
	public void init() {
		dao = new LoanDaoImpl();
		service = new LoanServiceImpl();
	}
	
	@Test
	public void testSaveLoan() {
		Loan loan = new Loan(20000,0.0,2,1234);
		service.applyLoan(1234, loan);
		assertEquals(true, dao.saveLoan(1234, loan));
	}
	
	@Test
	public void testgetLoanDetails() {
		try {
			Loan loan = new Loan(20000, 0.0, 2, 1111);
			service.applyLoan(1111, loan);
			Loan actual = dao.getLoanDetails(1111);
			assertEquals(actual.toString(), dao.getLoanDetails(1111).toString());
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	@Test(expected = LoanException.class)
	public void testgetLoanDetailsException() throws LoanException {
		dao.getLoanDetails(5555);
	}
	
	@Test
	public void testgetTransaction() {
		try {
			Loan loan = new Loan(20000, 0.0, 2, 1234);
			boolean status;
			service.applyLoan(1234, loan);
			service.payEmi(1234);
			service.payEmi(1234);
			List<Transaction> listTemp = dao.getTransaction(1234);
			if (listTemp.isEmpty()) {
				status = false;
			} else {
				status = true;
			}

			assertEquals(true, status);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
}
