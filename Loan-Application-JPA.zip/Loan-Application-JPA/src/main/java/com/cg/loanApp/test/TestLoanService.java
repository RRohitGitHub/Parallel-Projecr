package com.cg.loanApp.test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.cg.loanApp.dao.LoanDao;
import com.cg.loanApp.dao.LoanDaoImpl;
import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.exception.LoanException;
import com.cg.loanApp.service.LoanService;
import com.cg.loanApp.service.LoanServiceImpl;

public class TestLoanService {

	private LoanService service;
	private LoanDao dao;
	
	@Before
	public void init() {
		service = new LoanServiceImpl();
		dao = new LoanDaoImpl();
	}
	
	
	/**
	 * Testing testCalculateEmi() from service 
	 */
	@Test
	public void testCalculateEmi(){
		double emi = service.calculateEmi(20000, 10, 2);
		assertEquals(1016.992467812966, emi, 0.0000000000001);
	}
	
	
	/**
	 * Testing foreclose() from service
	 */
	@Test
	public void testForeclose() {
		try {
			Loan loan = new Loan(20000, 0.0, 2, 1234);
			service.applyLoan(1234, loan);
			service.foreclose(1234);
			Loan tempLoan = dao.getLoanDetails(1234);
			assertEquals(0.0, tempLoan.getLoanAmount(),0.01);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	
}
