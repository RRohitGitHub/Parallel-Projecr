package com.cg.loanApp.service;

import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.exception.LoanException;

public interface LoanService {

	final double RATE_OF_INTEREST = 10;
	
	boolean applyLoan(int accountNo, Loan loan);
	void showBalance(int accountNo) throws LoanException;
	void payEmi(int accountNo) throws LoanException;
	void foreclose(int accountNo) throws LoanException;
	double calculateEmi(double principleAmt,double rate,int tenure);
	void printTransaction(int accountNo) throws LoanException;
	
}
