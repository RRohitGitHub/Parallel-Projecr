package com.cg.loanApp.exception;

public class LoanException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoanException() {
		super();
	}

	public LoanException(String msg) {
		super(msg);
	}
}
