package com.cg.loanApp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.dto.Transaction;
import com.cg.loanApp.exception.LoanException;


public class LoanDaoImpl implements LoanDao {

	EntityManagerFactory factory;
	EntityManager em;
	EntityTransaction txn;

	public LoanDaoImpl() {
		factory = Persistence.createEntityManagerFactory("Oracle");
		em = factory.createEntityManager();
		txn = em.getTransaction();
	}

	public boolean saveLoan(int accountNo, Loan loan) {
		txn.begin();
		em.persist(loan);
		txn.commit();

		return true;
	}

	public Loan getLoanDetails(int accountNo) throws LoanException {
		Loan loan = em.find(Loan.class, accountNo);
		if(loan==null) {
			throw new LoanException("Loan with account no "+accountNo+" not found in database");
		}
		return loan;
	}

	public void updateAmount(int accountNo, Loan loan) {
		txn.begin();
		em.persist(loan);
		txn.commit();
	}

	public void saveTransaction(int accountNo, Transaction txns) {
		txn.begin();
		em.persist(txns);
		txn.commit();
	}

	public List<Transaction> getTransaction(int accountNo) throws LoanException {

		List<Transaction> txnAll = em.createQuery("from Transaction where accountNo=" + accountNo).getResultList();
		if(txnAll==null) {
			throw new LoanException("Loan with account no "+accountNo+" not found in database");
		}
		return txnAll;
	}

}
