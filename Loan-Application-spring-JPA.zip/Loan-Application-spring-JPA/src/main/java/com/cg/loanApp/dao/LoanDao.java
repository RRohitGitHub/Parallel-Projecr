package com.cg.loanApp.dao;

import java.util.List;

import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.dto.Transaction;
import com.cg.loanApp.exception.LoanException;


public interface LoanDao {
	
	boolean saveLoan(int accountNo,Loan loan);
	Loan getLoanDetails(int accountNo) throws LoanException;
	void updateAmount(int accountNo,Loan loan);
	void saveTransaction(int accountNo,Transaction txn);
	List<Transaction> getTransaction(int accountNo) throws LoanException;
//	List<Transaction> getTxnList();
//	Transaction displayTransaction(int accountNo);
//	void transactions(Transaction txns);
}
