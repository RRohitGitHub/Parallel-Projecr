package com.cg.loanApp.ui;

import java.util.Scanner;

import com.cg.loanApp.dto.Loan;
import com.cg.loanApp.exception.LoanException;
import com.cg.loanApp.service.LoanService;
import com.cg.loanApp.service.LoanServiceImpl;

public class LoanClient {
	private LoanService service = new LoanServiceImpl();
	Scanner sc = new Scanner(System.in);

	public void applyForLoan() {
		int accountNo;
		System.out.println("Enter account no");
		accountNo = sc.nextInt();
		System.out.println("Enter amount");
		double principle = sc.nextDouble();
		System.out.println("Enter duration of time in years");
		int tenure = sc.nextInt();
		Loan loan = new Loan(principle, 0.0, tenure, accountNo);
		if (service.applyLoan(accountNo, loan)) {
			System.out.println("Loan Applied Successfully");
		} else {
			System.out.println("Loan Cannot be applied");
		}
	}

	public void showBal() {
		int accountNo;
		System.out.println("Enter account no");
		accountNo = sc.nextInt();
		try {
			service.showBalance(accountNo);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}

	public void calcEmi() {
		double principle;
		int time;
		double rate;
		System.out.println("Enter principle amount");
		principle = sc.nextDouble();
		System.out.println("Enter time period");
		time = sc.nextInt();
		System.out.println("Enter rate of interest");
		rate = sc.nextDouble();
		System.out.println(service.calculateEmi(principle, rate, time));
	}

	public void forecloseLoan() {
		int accountNo;
		System.out.println("Enter account no");
		accountNo = sc.nextInt();
		try {
			service.foreclose(accountNo);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}

	public void payEmi() {
		int accountNo;
		System.out.println("Enter account no");
		accountNo = sc.nextInt();
		try {
			service.payEmi(accountNo);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}

	}

	public void printTransaction() {

		System.out.println("Enter account no");
		int accountNo = sc.nextInt();
		System.out.println("Print transaction");
		try {
			service.printTransaction(accountNo);
		} catch (LoanException e) {
			System.out.println(e.getMessage());
		}
	}

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		LoanClient c = new LoanClient();
		int ch = 0;
		do {
			System.out.println("1: Apply Loan");
			System.out.println("2: Show Balance");
			System.out.println("3: Pay EMI");
			System.out.println("4: Foreclose");
			System.out.println("5: Calculate EMI");
			System.out.println("6: Print Transactions");
			System.out.println("7: EXIT");
			System.out.println("Enter your choice");
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				c.applyForLoan();
				break;
			case 2:
				c.showBal();
				break;
			case 3:
				c.payEmi();
				break;
			case 4:
				c.forecloseLoan();
				break;
			case 5:
				c.calcEmi();
				break;
			case 6:
				c.printTransaction();
				break;

			case 7:
				System.out.println("Exited");
				break;
			default:
				System.out.println("Please Enter correct choice");
				break;
			}

		} while (ch != 7);
	}
}
